
package vistacontrol;

import utils.Lectura;
import utils.Utilitarios;
import static vistacontrol.Indexprincipal.cantidad;
import static vistacontrol.Indexprincipal.dni;
import static vistacontrol.Indexprincipal.nombre;

/**
 *
 * @author naara
 */
public class Indexdepersonas {
    private static Lectura leer= new Lectura();
    public static void menudeusuarios(){
        int opcion;
        do { 
            Utilitarios.superlineasblanco();
            System.out.println("""
                           --Menu de Usuarios--
                           1.Agregar nuevos Usuarios
                           2.Eliminar Usuarios
                           3.Editar Usuarios
                           4.Listar Personas
                           5.Regresar
                           """);
            System.out.print("Ingrese un numero[1-5]:");
            opcion =leer.entero();
            switch (opcion) {
                case 1 -> agregar();
                case 2 -> eliminar();
                case 3 -> editar();
                case 4 -> lista();
                case 5 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=5);
        Utilitarios.lineasenblano();
    }
    public static void agregar(){
        System.out.println("\n---REGISTRAR NUEVA PERSONA---");
        String res,sal = "n",res1;
        do {            
            cantidad++;
            System.out.print("DNI:");
            dni[cantidad]= leer.cadena();
            System.out.print("Nombre:");
            nombre[cantidad]= leer.cadena();   
            Indexiglesia.usuasignar();
            System.out.print("Desea volver a ingresar un nuevo(Y/N):");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void eliminar(){
        System.out.println("---ELIMINAR PERSONAS---");
        String sal="n", res;
        do {   
            if(cantidad==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay personas");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la psoicion a eliminar: ");
            int posicion = leer.entero();
            posicion--;
            for (int i = posicion; i < cantidad; i++) {
                dni[i]=dni[i+1];
                nombre[i]=nombre[i+1];
            }
            dni[cantidad]=null;
            nombre[cantidad]=null;
            cantidad--;
            System.out.println("Se elimino correctamente");
            System.out.print("Desea volver a ingresar un nuevo(Y/N):");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void editar(){
        String res, sal="n";
        System.out.println("-Editar Personas-");
        lista();
        do {            
            System.out.print("Indique la posicion  editar:");
            int posicion = leer.entero();
            posicion--;
            System.out.print(">DNI anterior:"+dni[posicion]);
            System.out.print("\nIngrese el nuevo DNI:");
            dni[posicion]=leer.cadena();
            System.out.println("\n>Nombre anterior:"+nombre[posicion]);
            System.out.print("\nIngrese el nuevo Nombre:");
            nombre[posicion]=leer.cadena();
            System.out.println("< Editado correctamente");
            System.out.print("Desea volver a editar?(Y/N)");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void lista(){
        System.out.println("Nro\tDNI\t\tNOMBRE");
        int num=0;
        for (int i = 0; i <= cantidad; i++) {
            num++;
            System.out.println(num+"\t"+dni[i]+"\t"+nombre[i]);
        }
    }
}
