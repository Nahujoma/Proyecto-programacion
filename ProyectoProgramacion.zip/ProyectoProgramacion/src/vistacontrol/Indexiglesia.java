
package vistacontrol;

import utils.Lectura;
import utils.Utilitarios;
import static vistacontrol.Indexprincipal.cantidad;
import static vistacontrol.Indexprincipal.codigo;
import static vistacontrol.Indexprincipal.iglesia;
/**
 *
 * @author naara
 */
public class Indexiglesia {
    private static Lectura leer = new Lectura();
    public static int codiglesias=-1;
    public static int usuiglesia;
    public static void menu(){
        System.out.print("""
                           1.Agregar nueva iglesia
                           2.Asignar iglesia a Usuario
                           3.Regresar
                           """);
        System.out.print("Ingrese un numero[1-3]");
    }
    public static void agregar(){
        String sal = "n";
        String res;
        do {            
            codiglesias++;
            System.out.println("--Agregar iglesia--");
            System.out.print("Igrese la nueva iglesia:");
            iglesia[codiglesias]=leer.cadena();
            System.out.print("El numero de asignacion es:"+codiglesias);
            res = leer.cadena();
            System.out.print("Desea volver a ingresar una nueva iglesia(N/n):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void asignar(){
        System.out.println("--Asignacion de iglesias--");
        String res,sal="n";
        int usu,igle;
        do {            
            System.out.println("Elija el usuario a asignar: ");
            Indexdepersonas.lista();
            usu=leer.entero();
            System.out.println("Elija a la iglesia para asignarle:");
            lista();
            igle=leer.entero();
            codigo[usu]=igle;
            System.out.print("Desea volver a ingresar un diezmo?(Y/N):");
            res=leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));    
    }
    public static void usuasignar(){
        String res,sal="n";
        int usu,igle;           
            usu=cantidad;
            lista();
            System.out.print("\nElija a la iglesia para asignarle:");
            igle=leer.entero();
            codigo[usu]=igle;  
    }
    public static void lista(){
        System.out.println("\n--LISTA--");
        for (int i = 0; i < cantidad; i++) {
            System.out.println(i+1+". Iglesias:"+iglesia[i]);
        }
    }
    public static void menuiglesias(){
        int opcion;
        do {            
            menu();
            opcion=leer.entero();
            switch (opcion) {
                case 1 -> agregar();
                case 2 -> asignar();
                case 3 -> lista();
                case 4 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=4);
    }
}
