
package vistacontrol;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import utils.Lectura;
import utils.Utilitarios;

/**
 *
 * @author naara
 */
public class Indexprincipal {
    private static Lectura leer = new Lectura();
    public static String[] dni = new String[100];
    public static String[] nombre = new String[100];
    public static String[] iglesia = new String[100];
    public static String[] fecha = new String[100];
    public static double[] ofrenda = new double[1000];
    public static double[] diezmo = new double[1000];
    public static double[] aportes = new double[1000];
    public static int[] codigo = new int[1000];
    public static int cantidad =-1;
    public static void cargadordedatos(){
        cantidad++;
        dni[cantidad]="111";
        nombre[cantidad]="Juan";
        fecha[cantidad]="06/06";
        iglesia[cantidad]="Bartolome";
        diezmo[cantidad]=100;
        ofrenda[cantidad]=10;
        cantidad++;
        dni[cantidad]="40673624";
        nombre[cantidad]="Moises";
        fecha[cantidad]="01/01/2000";
        iglesia[cantidad]="Villa Union";
        diezmo[cantidad]=100;
        ofrenda[cantidad]=10;
        cantidad++;
        dni[cantidad]="40673624";
        nombre[cantidad]="Moises";
        fecha[cantidad]="01/01/2000";
        iglesia[cantidad]="Chosica";
        diezmo[cantidad]=100;
        ofrenda[cantidad]=10;
    }
    public static void listatotal(){
        System.out.println("Nro\tDNI\t\tNOMBRE\tFECHA DE BAUTIZO\tIGLESIA\t\tDIEZMOS\t\tOFRENDAS\t\tTOTALAPORTADO");
        int num=0;
        for (int i = 0; i <= cantidad; i++) {
            num++;
            System.out.println(num+"\t"+dni[i]+"\t"+nombre[i]+"\t"+fecha[i]+"\t\t"+iglesia[i]+"\t"+diezmo[i]+"$"+"\t\t"+ofrenda[i]+"$"+"\t\t\t"+(ofrenda[i]+diezmo[i])+"$");
        }
    }
    public static void usuariosinicio(){
        String usuario,contra,usu="grupo",con="3";
        System.out.println("--Bienvenido--");
        System.out.print("Ingrese su usuario:");
        usuario=leer.cadena();
        while (!usuario.equals(usu)) {            
            System.out.print("\nError, ingrese denuevo: ");
            usuario=leer.cadena();
        }
        System.out.print("Ingrese su contraseña:");
        contra=leer.cadena();
        while (!contra.equals(con)) {            
            System.out.print("Ingrese denuevo su contraseña:");
            contra=leer.cadena();
        }
    }
    public static void menuprincipal(){
        Utilitarios.superlineasblanco();
        Utilitarios.superlineasblanco();
        System.out.println("""
                           ---MENU PRINCIPAL---
                           1.Modificaciones entre los Usuarios
                           2.Agregar Tesoreria de los Usuarios
                           3.Asignar o Agregar nuevas Iglesias
                           4.Consulta de datos General
                           5.Salir del Programa
                           """);
    }
    public static void texto(){
        try {
            String nombrearchivo = "C:/Users/nati7/Downloads/datos.txt";
            FileWriter archivo = new FileWriter(nombrearchivo);
            PrintWriter escritor = new PrintWriter(archivo);
            escritor.println("Nro\tDNI\t\tNOMBRE\tFECHA DE BAUTIZO\tIGLESIA\t\tDIEZMOS\t\tOFRENDAS\t\tTOTAL APORTADO");
            escritor.println("-----------------------------------------------------------------------------------------------------------------------------------");
            for (int i = 0; i <= cantidad; i++) {
            escritor.println(i+1+"\t"+dni[i]+"\t"+nombre[i]+"\t"+fecha[i]+"\t\t"+iglesia[i]+"\t"+diezmo[i]+"$"+"\t\t"+ofrenda[i]+"$"+"\t\t\t"+(ofrenda[i]+diezmo[i])+"$");
            }
            escritor.close();
            Utilitarios.lineasenblano();
            System.out.println("Archivo creado");
        } catch (IOException e) {
            System.out.println("Error: Asegúrate de que las carpetas de la ruta existan.");
        }
    }
    public static void inicio(){
        int opcion;
        cargadordedatos();
        usuariosinicio();
        do {            
            menuprincipal();
            System.out.print("Ingrese un numero[1-5]:");
            opcion=leer.entero();
            switch (opcion) {
                case 1 -> Indexdepersonas.menudeusuarios();
                case 2 -> Indexdepositos.menuaportaciones();
                case 3 -> Indexiglesia.menuiglesias();
                case 4 -> texto();
                case 5 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=5);
        texto();
    }
}
