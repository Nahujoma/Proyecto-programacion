
package vistacontrol;

import utils.Lectura;
import utils.Utilitarios;
import static vistacontrol.Indexprincipal.cantidad;
import static vistacontrol.Indexprincipal.diezmo;
import static vistacontrol.Indexprincipal.dni;
import static vistacontrol.Indexprincipal.nombre;
import static vistacontrol.Indexprincipal.ofrenda;

/**
 *
 * @author naara
 */
//Aun no ha acado
//Aun no ha acado
//Aun no ha acado
//Aun no ha acado
//Aun no ha acado
//Aun no ha acado
public class Indexdepositos {
    private static Lectura leer = new Lectura();
    public static void menuaportaciones(){
        int opcion;
        do {            
            System.out.println("""
                               \n--Bienvenido a Aportaciones--
                               1.Agregar Diezmos
                               2.Agregar Ofrendas
                               3.Total de aportaciones
                               4.Regresar
                               """);
            System.out.print("Ingrese un numero[1-4]:");
            opcion=leer.entero();
            switch (opcion) {
                case 1 -> diezmos();
                case 2 -> ofrendas();
                case 3 -> total();
                case 4 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=4);
        Utilitarios.superlineasblanco();
    }
    //revisar el codigo
    public static void diezmos(){
        int posicion;
        System.out.println("--DIEZMOS--");
        Indexdepersonas.lista();
        String res,sal="n";
        do {
            System.out.print("A que usuario se desea agregar su diezmo:");
            posicion = leer.entero();
            posicion--;
            if (posicion<=cantidad && posicion>-1) {
                System.out.print("Ingrese el monto del diezmo:");
                diezmo[posicion]=leer.decimal();
            }else{
                Utilitarios.error();
            } 
            System.out.print("Desea volver a ingresar un diezmo?(Y/N):");
            res=leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void ofrendas(){
        int posicion;
        System.out.println("--OFRENDAS--");
        Indexdepersonas.lista();
        String res,sal="n";
        do {
            System.out.print("A que usuario se desea agregar su ofrenda:");
            posicion = leer.entero();
            posicion--;
            if (posicion<=cantidad && posicion>-1) {
                System.out.print("Ingrese el monto de la ofrenda:");
                ofrenda[posicion]=leer.decimal();
            }else{
                Utilitarios.error();
            } 
            System.out.print("Desea volver a ingresar un diezmo?(Y/N):");
            res=leer.cadena();
        } while (!(res.toLowerCase()).equals(sal)); 
    }
    public static void proyectolocal(){
        int posicion;
        System.out.println("--PROYECTO LOCAL--");
        Indexdepersonas.lista();
        String res,sal="n";
        do {
            System.out.print("A que usuario se desea agregar su ofrenda:");
            posicion = leer.entero();
            posicion--;
            if (posicion<=cantidad && posicion>-1) {
                System.out.print("Ingrese el monto de la ofrenda:");
                ofrenda[posicion]=leer.decimal();
            }else{
                Utilitarios.error();
            } 
            System.out.print("Desea volver a ingresar un diezmo?(Y/N):");
            res=leer.cadena();
        } while (!(res.toLowerCase()).equals(sal)); 
    }
    public static void institutos(){
        int posicion;
        System.out.println("--INSTITUTOS--");
        Indexdepersonas.lista();
        String res,sal="n";
        do {
            System.out.print("A que usuario se desea agregar su ofrenda:");
            posicion = leer.entero();
            posicion--;
            if (posicion<=cantidad && posicion>-1) {
                System.out.print("Ingrese el monto de la ofrenda:");
                ofrenda[posicion]=leer.decimal();
            }else{
                Utilitarios.error();
            } 
            System.out.print("Desea volver a ingresar un diezmo?(Y/N):");
            res=leer.cadena();
        } while (!(res.toLowerCase()).equals(sal)); 
    }
    public static void total(){
        System.out.println("Nro\tDNI\t\tNOMBRE\t\tDIEZMO\tOFRENDA");
        int num=0;
        for (int i = 0; i <= cantidad; i++) {
            num++;
            System.out.println(num+"\t"+dni[i]+"\t"+nombre[i]+"\t\t"+diezmo[i]+"$"+"\t"+ofrenda[i]+"$"+"\t"+(ofrenda[i]+diezmo[i])+"$");
        }
    }
}
