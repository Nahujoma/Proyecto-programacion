/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vistacontrol;

import java.util.Scanner;

/**
 *
 * @author alum.l4
 */
public class saladepruebas {
    private static int[] dni = new int[1000];
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        System.out.println("Ingrese la cntidad de dni");
        int cantidad;
        cantidad = Integer.parseInt(teclado.nextLine());
        for (int i = 0; i < cantidad; i++) {
            dni[i]=Integer.parseInt(teclado.nextLine());
        }
        System.out.println("El nuevo a agregar");
        dni[cantidad]= Integer.parseInt(teclado.nextLine());
        for (int i = 0; i < cantidad; i++) {
            if (dni[i]==dni[cantidad]) {
                System.out.println("Hay una coicidencia");
            }
        }
        teclado.close();
        
    }
}
