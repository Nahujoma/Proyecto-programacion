
package vistacontrol;

import utils.Lectura;
import utils.Utilitarios;
import static vistacontrol.Indexprincipal.cantidad;
import static vistacontrol.Indexprincipal.codigo;
import static vistacontrol.Indexprincipal.iglesia;
import static vistacontrol.Indexprincipal.codiglesias;
/**
 *
 * @author naara
 */
public class Indexiglesia {
    private static Lectura leer = new Lectura();
    public static int usuiglesia;
    public static void menu(){
        System.out.print("""
                           1.Agregar nueva iglesia
                           2.Eliminar iglesia
                           3.Editar iglesia
                           4.Listar iglesias
                           5.Buscar 
                           6.Regresar
                           """);
        System.out.print("Ingrese un numero[1-6]");
    }
    public static void agregar(){
        String sal = "n";
        String res;
        do {            
            codiglesias++;
            System.out.println("--Agregar iglesia--");
            System.out.print("Igrese la nueva iglesia:");
            iglesia[codiglesias]=leer.cadena();
            System.out.print("El numero de asignacion es:"+codiglesias+1);
            System.out.print("Desea volver a ingresar una nueva iglesia(N/n):");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void eliminar(){
        String res,sal="n";
        do { 
            System.out.println("--Eliminar iglesias--");
            if(codiglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la posicion a eliminar: ");
            int posicion = leer.entero();
            posicion--;
            for (int i = posicion; i < codiglesias; i++) {
                iglesia[i]=iglesia[i+1];
            }
            iglesia[codiglesias]=null;
            codiglesias--;
            System.out.println("Se elimino correctamente");
            res = leer.cadena();
            System.out.print("Desea volver a ingresar una nueva iglesia(N/n):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void editar(){
        String res,sal="n";
        do { 
            System.out.println("--Editar iglesia--");
            if(codiglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la posicion a editar: ");
            int posicion = leer.entero();
            posicion--;
            iglesia[posicion]=leer.cadena();
            System.out.println("Se edito correctamente");
            res = leer.cadena();
            System.out.print("Desea volver a editar(Y/N):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void usuasignar(){
        String res,sal="n";
        int usu,igle;           
            usu=cantidad;
            lista();
            System.out.print("\nElija a la iglesia para asignarle:");
            igle=leer.entero();
            codigo[usu]=igle;  
    }
    public static void lista(){
        System.out.println("\n--LISTA--");
        for (int i = 0; i < codiglesias+1; i++) {
            System.out.println(i+1+". Iglesias:"+iglesia[i]);
        }
    }
    public static void buscar(){
        String res,sal="n";
        do { 
            System.out.println("--Buscador de usuarios--");
            if(codiglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la iglesia para buscar usuarios: ");
            int posicion = leer.entero();
            posicion--;
            for (int i = 0; i < 10; i++) {
                System.out.println(Indexprincipal.dni[codiglesias]);
            }
            res = leer.cadena();
            System.out.print("Desea volver a editar(Y/N):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void menuiglesias(){
        int opcion;
        do {            
            menu();
            opcion=leer.entero();
            switch (opcion) {
                case 1 -> agregar();
                case 2 -> eliminar();
                case 3 -> editar();
                case 4 -> lista();
                case 5 -> buscar();
                case 6 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=4);
    }
}
