
package vistacontrol;

import utils.Lectura;
import utils.Utilitarios;
import static vistacontrol.Indexprincipal.cantidad;
import static vistacontrol.Indexprincipal.codigo;
import static vistacontrol.Indexprincipal.iglesia;
import static vistacontrol.Indexprincipal.caniglesias;
/**
 *
 * @author naara
 */
public class Indexiglesia {
    private static Lectura leer = new Lectura();
    public static int usuiglesia;
    public static void menu(){
        Utilitarios.lineasenblano();
        System.out.print("""
                           --MENU DE IGLESIAS--
                         
                           1.Agregar nueva iglesia
                           2.Eliminar iglesia
                           3.Editar iglesia
                           4.Listar iglesias
                           5.Buscar 
                           6.Regresar
                           """);
        System.out.print("Ingrese un numero[1-6]:");
    }
    public static void agregar(){
        String sal = "n";
        String res;
        do {            
            caniglesias++;
            System.out.println("--Agregar iglesia--");
            System.out.print("Igrese la nueva iglesia:");
            iglesia[caniglesias]=leer.cadena();
            System.out.println("El numero de asignacion es:"+caniglesias+1);
            System.out.print("Desea volver a ingresar una nueva iglesia(N/n):");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void eliminar(){
        String res,sal="n";
        do { 
            System.out.println("--Eliminar iglesias--");
            if(caniglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la posicion a eliminar: ");
            int posicion = leer.entero();
            posicion--;
            for (int i = posicion; i < caniglesias; i++) {
                iglesia[i]=iglesia[i+1];
            }
            iglesia[caniglesias]=null;
            caniglesias--;
            System.out.println("Se elimino correctamente");
            res = leer.cadena();
            System.out.print("Desea volver a ingresar una nueva iglesia(N/n):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void editar(){
        String res,sal="n";
        do { 
            System.out.println("--Editar iglesia--");
            if(caniglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la posicion a editar: ");
            int posicion = leer.entero();
            posicion--;
            iglesia[posicion]=leer.cadena();
            System.out.println("Se edito correctamente");
            res = leer.cadena();
            System.out.print("\nDesea volver a editar(Y/N):");
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void usuasignar(){
        String res,sal="n";
        int igle;           
            lista();
            System.out.print("\nElija a la iglesia para asignarle:");
            igle=leer.entero();
            codigo[cantidad]=igle;  
    }
    public static void lista(){
        System.out.println("\n--LISTA--");
        for (int i = 0; i < caniglesias+1; i++) {
            System.out.println(i+1+". Iglesias:"+iglesia[i]);
        }
    }
    public static void buscar(){
        String res,sal="n";
        do { 
            System.out.println("--Buscador de usuarios--");
            if(caniglesias==-1){
                Utilitarios.lineasenblano();
                System.out.println("Ya no hay iglesias");
                Utilitarios.lineasenblano();
                return;
            }
            lista();
            System.out.print("Indique la iglesia para buscar usuarios: ");
            int posicion = leer.entero();
            for (int i = 0; i < cantidad+1; i++) {
                if (codigo[i]==posicion) {
                    System.out.print("\nDni:"+Indexprincipal.dni[i]+"\tNombre:"+Indexprincipal.nombre[i]);
                }
            }
            System.out.print("\nDesea volver a buscar(Y/N):");
            res = leer.cadena();
        } while (!(res.toLowerCase()).equals(sal));
    }
    public static void menuiglesias(){
        int opcion;
        do {            
            menu();
            opcion=leer.entero();
            switch (opcion) {
                case 1 -> agregar();
                case 2 -> eliminar();
                case 3 -> editar();
                case 4 -> lista();
                case 5 -> buscar();
                case 6 -> Utilitarios.salir();
                default -> Utilitarios.error();
            }
        } while (opcion!=6);
    }
}
